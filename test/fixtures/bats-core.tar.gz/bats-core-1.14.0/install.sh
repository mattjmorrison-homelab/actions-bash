#!/bin/sh
set -e
target="$1"
mkdir -p "$target/bin"
printf '#!/bin/sh\necho fake-bats\n' > "$target/bin/bats"
chmod +x "$target/bin/bats"
